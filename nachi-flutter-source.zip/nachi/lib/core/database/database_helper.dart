import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;
  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('nachi.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE conversations (
        id TEXT PRIMARY KEY,
        contact_name TEXT NOT NULL,
        avatar_initials TEXT NOT NULL,
        avatar_color TEXT NOT NULL,
        date_created TEXT NOT NULL,
        duration_seconds INTEGER NOT NULL,
        tag TEXT DEFAULT 'General',
        tag_color TEXT DEFAULT '#636e72',
        is_starred INTEGER DEFAULT 0,
        audio_file_path TEXT,
        transcript TEXT,
        summary_json TEXT,
        topics TEXT,
        is_encrypted INTEGER DEFAULT 1
      )
    ''');
    await db.execute('''
      CREATE TABLE reminders (
        id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL,
        reminder_text TEXT NOT NULL,
        reminder_time TEXT,
        is_done INTEGER DEFAULT 0,
        FOREIGN KEY (conversation_id) REFERENCES conversations(id)
      )
    ''');
  }

  Future<int> insertConversation(Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.insert('conversations', row);
  }

  Future<List<Map<String, dynamic>>> getAllConversations() async {
    final db = await instance.database;
    return await db.query('conversations', orderBy: 'date_created DESC');
  }

  Future<List<Map<String, dynamic>>> searchConversations(String query) async {
    final db = await instance.database;
    return await db.query('conversations',
      where: 'contact_name LIKE ? OR transcript LIKE ? OR topics LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'date_created DESC');
  }

  Future<int> updateConversation(Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.update('conversations', row, where: 'id = ?', whereArgs: [row['id']]);
  }

  Future<int> deleteConversation(String id) async {
    final db = await instance.database;
    return await db.delete('conversations', where: 'id = ?', whereArgs: [id]);
  }
}
