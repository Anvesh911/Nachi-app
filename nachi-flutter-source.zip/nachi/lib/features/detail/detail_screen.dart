import 'package:flutter/material.dart';
import '../../shared/theme/app_theme.dart';

class DetailScreen extends StatefulWidget {
  final Map<String, dynamic> conversation;
  const DetailScreen({super.key, required this.conversation});
  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isPlaying = false;
  double _playProgress = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.conversation;
    return Scaffold(
      backgroundColor: NachiColors.background,
      body: SafeArea(
        child: Column(children: [
          _buildHeader(c),
          _buildAudioPlayer(c),
          _buildTabBar(),
          Expanded(child: TabBarView(controller: _tabController, children: [
            _buildSummaryTab(c),
            _buildTranscriptTab(c),
            _buildRemindersTab(c),
          ])),
        ]),
      ),
    );
  }

  Widget _buildHeader(Map c) => Padding(
    padding: const EdgeInsets.fromLTRB(8, 8, 16, 8),
    child: Row(children: [
      IconButton(icon: const Icon(Icons.chevron_left, color: NachiColors.neonBlue, size: 32), onPressed: () => Navigator.pop(context)),
      Container(
        width: 36, height: 36, decoration: BoxDecoration(
          color: const Color(0xFF00B4FF).withOpacity(0.2),
          borderRadius: BorderRadius.circular(10)),
        child: Center(child: Text(c['avatar'] ?? 'NA', style: const TextStyle(fontFamily: 'Sora', fontWeight: FontWeight.w700, fontSize: 13, color: NachiColors.neonBlue)))),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(c['contact'] ?? 'Unknown', style: const TextStyle(fontFamily: 'Sora', fontWeight: FontWeight.w700, fontSize: 15, color: NachiColors.textPrimary)),
        Text('${c['date'] ?? ''} · ${c['duration'] ?? ''}', style: const TextStyle(fontSize: 11, color: NachiColors.textMuted)),
      ])),
      IconButton(icon: Icon(c['starred'] == true ? Icons.star_rounded : Icons.star_border_rounded, color: c['starred'] == true ? Colors.amber : NachiColors.textMuted), onPressed: () {}),
      IconButton(icon: const Icon(Icons.ios_share, color: NachiColors.neonBlue, size: 20), onPressed: () {}),
    ]),
  );

  Widget _buildAudioPlayer(Map c) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 20),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: NachiColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: NachiColors.border)),
    child: Column(children: [
      Row(children: [
        GestureDetector(
          onTap: () => setState(() => _isPlaying = !_isPlaying),
          child: Container(
            width: 40, height: 40, decoration: const BoxDecoration(color: NachiColors.neonBlue, shape: BoxShape.circle),
            child: Center(child: Icon(_isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.black, size: 20)),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SliderTheme(
            data: SliderThemeData(trackHeight: 4, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6), overlayShape: SliderComponentShape.noOverlay),
            child: Slider(value: _playProgress, onChanged: (v) => setState(() => _playProgress = v),
              activeColor: NachiColors.neonBlue, inactiveColor: NachiColors.border)),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('0:00', style: const TextStyle(fontSize: 10, color: NachiColors.textMuted)),
            Text(c['duration'] ?? '0:00', style: const TextStyle(fontSize: 10, color: NachiColors.textMuted)),
          ]),
        ])),
      ]),
    ]),
  );

  Widget _buildTabBar() => Container(
    margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
    decoration: BoxDecoration(color: NachiColors.surfaceVariant, borderRadius: BorderRadius.circular(10), border: Border.all(color: NachiColors.border)),
    child: TabBar(
      controller: _tabController,
      indicator: BoxDecoration(color: NachiColors.neonBlue.withOpacity(0.15), borderRadius: BorderRadius.circular(9)),
      indicatorSize: TabBarIndicatorSize.tab,
      labelColor: NachiColors.neonBlue, unselectedLabelColor: NachiColors.textMuted,
      labelStyle: const TextStyle(fontFamily: 'Sora', fontSize: 12, fontWeight: FontWeight.w600),
      tabs: const [Tab(text: 'Summary'), Tab(text: 'Transcript'), Tab(text: 'Reminders')],
    ),
  );

  Widget _buildSummaryTab(Map c) => ListView(padding: const EdgeInsets.all(20), children: [
    _glassCard('🔑 Key Points', NachiColors.neonBlue, (c['keyPoints'] as List? ?? ['No key points']).map((p) => '· $p').join('\n')),
    _glassCard('🤝 Promises & Tasks', NachiColors.purple, (c['promises'] as List? ?? ['No promises']).map((p) => '□ $p').join('\n')),
    _glassCard('📅 Dates & Plans', NachiColors.orange, (c['dates'] as List? ?? ['No dates']).map((p) => '◆ $p').join('\n')),
    Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: NachiColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: NachiColors.border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('EMOTIONAL TONE', style: TextStyle(fontSize: 11, color: NachiColors.textMuted, letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Text(c['toneEmoji'] ?? '💬', style: const TextStyle(fontSize: 24)),
        const SizedBox(height: 4),
        Text(c['tone'] ?? 'Neutral', style: const TextStyle(fontFamily: 'Sora', fontSize: 15, fontWeight: FontWeight.w600, color: NachiColors.textPrimary)),
      ]),
    ),
  ]);

  Widget _glassCard(String title, Color color, String content) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: NachiColors.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: color.withOpacity(0.2))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: TextStyle(fontSize: 11, color: color, letterSpacing: 1, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Text(content, style: const TextStyle(fontSize: 13, color: NachiColors.textSecondary, height: 1.7)),
    ]),
  );

  Widget _buildTranscriptTab(Map c) => SingleChildScrollView(
    padding: const EdgeInsets.all(20),
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: NachiColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: NachiColors.border)),
      child: Text(c['transcript'] ?? 'No transcript available.', style: const TextStyle(fontSize: 13.5, color: NachiColors.textSecondary, height: 1.8)),
    ),
  );

  Widget _buildRemindersTab(Map c) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('THINGS TO REMEMBER', style: TextStyle(fontSize: 11, color: NachiColors.textMuted, letterSpacing: 1.5)),
    const SizedBox(height: 12),
    ...(c['reminders'] as List? ?? []).map((r) => Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: NachiColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: NachiColors.border)),
      child: Row(children: [
        Container(width: 20, height: 20, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: NachiColors.neonBlue, width: 2))),
        const SizedBox(width: 12),
        Expanded(child: Text(r, style: const TextStyle(fontSize: 13.5, color: NachiColors.textSecondary))),
      ]),
    )),
    const SizedBox(height: 8),
    ElevatedButton(
      onPressed: () {},
      style: ElevatedButton.styleFrom(
        backgroundColor: NachiColors.neonBlue.withOpacity(0.15),
        foregroundColor: NachiColors.neonBlue,
        side: const BorderSide(color: NachiColors.neonBlue),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(vertical: 14)),
      child: const Text('+ Set Reminder', style: TextStyle(fontFamily: 'Sora', fontWeight: FontWeight.w700))),
  ]);
}
