import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import '../../shared/theme/app_theme.dart';
import '../home/home_screen.dart';

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _pin = '';
  final _correctPin = '1234';
  final _localAuth = LocalAuthentication();
  bool _error = false;

  void _onKey(dynamic k) {
    if (k == '⌫') {
      setState(() => _pin = _pin.isEmpty ? '' : _pin.substring(0, _pin.length - 1));
    } else if (_pin.length < 4) {
      setState(() { _pin += k.toString(); _error = false; });
      if (_pin.length == 4) _checkPin();
    }
  }

  void _checkPin() {
    if (_pin == _correctPin) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    } else {
      setState(() { _error = true; _pin = ''; });
    }
  }

  Future<void> _biometricAuth() async {
    try {
      final authenticated = await _localAuth.authenticate(
        localizedReason: 'Unlock Nachi',
        options: const AuthenticationOptions(biometricOnly: true),
      );
      if (authenticated && mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
      }
    } catch (e) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NachiColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('🔐', style: TextStyle(fontSize: 48)),
              const SizedBox(height: 16),
              const Text('Nachi', style: TextStyle(fontFamily: 'Sora', fontSize: 24, fontWeight: FontWeight.w700, color: NachiColors.textPrimary)),
              const SizedBox(height: 8),
              Text(_error ? 'Wrong PIN. Try again.' : 'Enter PIN to continue',
                style: TextStyle(color: _error ? NachiColors.red : NachiColors.textMuted, fontSize: 14)),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (i) => Container(
                  width: 14, height: 14, margin: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: i < _pin.length ? NachiColors.neonBlue : NachiColors.border,
                    boxShadow: i < _pin.length ? [const BoxShadow(color: NachiColors.neonBlue, blurRadius: 8)] : null,
                  ),
                )),
              ),
              const SizedBox(height: 48),
              GridView.count(
                crossAxisCount: 3, shrinkWrap: true,
                childAspectRatio: 1.4, mainAxisSpacing: 12, crossAxisSpacing: 12,
                children: [1,2,3,4,5,6,7,8,9,'',0,'⌫'].map((k) => k == ''
                  ? const SizedBox()
                  : GestureDetector(
                    onTap: () => _onKey(k),
                    child: Container(
                      decoration: BoxDecoration(
                        color: NachiColors.surface, borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: NachiColors.border),
                      ),
                      child: Center(child: Text(k.toString(),
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600, color: NachiColors.textPrimary))),
                    ))).toList(),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: _biometricAuth,
                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('👆', style: TextStyle(fontSize: 22)),
                  SizedBox(width: 8),
                  Text('Use Fingerprint', style: TextStyle(color: NachiColors.neonBlue, fontSize: 14)),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
