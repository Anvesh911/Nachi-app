import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../shared/theme/app_theme.dart';

class RecordingSheet extends StatefulWidget {
  const RecordingSheet({super.key});
  @override
  State<RecordingSheet> createState() => _RecordingSheetState();
}

class _RecordingSheetState extends State<RecordingSheet> with TickerProviderStateMixin {
  bool _consentGiven = false;
  bool _isRecording = false;
  int _seconds = 0;
  String _contactName = '';
  late AnimationController _waveController;

  @override
  void initState() {
    super.initState();
    _waveController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _waveController.dispose();
    super.dispose();
  }

  String get _timeDisplay {
    final m = (_seconds ~/ 60).toString().padLeft(2, '0');
    final s = (_seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0D1117),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(top: BorderSide(color: NachiColors.border)),
      ),
      padding: const EdgeInsets.fromLTRB(28, 16, 28, 48),
      child: !_consentGiven ? _buildConsent() : _buildRecorder(),
    );
  }

  Widget _buildConsent() => Column(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 40, height: 4, decoration: BoxDecoration(color: NachiColors.border, borderRadius: BorderRadius.circular(2))),
    const SizedBox(height: 24),
    const Text('🎙️', style: TextStyle(fontSize: 48)),
    const SizedBox(height: 16),
    const Text('Recording Consent', style: TextStyle(fontFamily: 'Sora', fontSize: 18, fontWeight: FontWeight.w700, color: NachiColors.textPrimary)),
    const SizedBox(height: 12),
    const Text(
      'Please ensure all parties in this conversation have given consent to be recorded. Recording without consent may violate local laws (IT Act, 2000).',
      textAlign: TextAlign.center,
      style: TextStyle(fontSize: 13, color: NachiColors.textMuted, height: 1.7)),
    const SizedBox(height: 28),
    Row(children: [
      Expanded(child: OutlinedButton(
        onPressed: () => Navigator.pop(context),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: NachiColors.border),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          padding: const EdgeInsets.symmetric(vertical: 14)),
        child: const Text('Cancel', style: TextStyle(color: NachiColors.textMuted, fontFamily: 'Sora')))),
      const SizedBox(width: 12),
      Expanded(child: ElevatedButton(
        onPressed: () => setState(() => _consentGiven = true),
        style: ElevatedButton.styleFrom(
          backgroundColor: NachiColors.neonBlue, foregroundColor: Colors.black,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          padding: const EdgeInsets.symmetric(vertical: 14)),
        child: const Text('I Consent ✓', style: TextStyle(fontFamily: 'Sora', fontWeight: FontWeight.w700)))),
    ]),
  ]);

  Widget _buildRecorder() => Column(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 40, height: 4, decoration: BoxDecoration(color: NachiColors.border, borderRadius: BorderRadius.circular(2))),
    const SizedBox(height: 24),
    if (_isRecording) ...[
      const Text('● RECORDING', style: TextStyle(fontSize: 11, color: NachiColors.red, letterSpacing: 2, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      Text(_timeDisplay, style: const TextStyle(fontFamily: 'Sora', fontSize: 48, fontWeight: FontWeight.w800, color: NachiColors.textPrimary)),
      const SizedBox(height: 16),
      AnimatedBuilder(
        animation: _waveController,
        builder: (_, __) => Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(24, (i) {
            final h = (20 + 30 * (_waveController.value * (i % 3 == 0 ? 1 : i % 2 == 0 ? 0.6 : 0.4))).clamp(4.0, 48.0);
            return Container(
              width: 4, margin: const EdgeInsets.symmetric(horizontal: 2),
              height: h,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [NachiColors.neonBlue, NachiColors.purple], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                borderRadius: BorderRadius.circular(2)),
            );
          }),
        ),
      ),
    ] else ...[
      const Text('Ready to record', style: TextStyle(fontFamily: 'Sora', fontSize: 18, fontWeight: FontWeight.w600, color: NachiColors.textPrimary)),
      const SizedBox(height: 20),
      TextField(
        style: const TextStyle(color: NachiColors.textSecondary, fontFamily: 'Sora', fontSize: 13),
        decoration: InputDecoration(
          hintText: 'Contact name (optional)',
          hintStyle: const TextStyle(color: NachiColors.textMuted),
          filled: true, fillColor: NachiColors.surfaceVariant,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: NachiColors.border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: NachiColors.border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: NachiColors.neonBlue)),
        ),
        onChanged: (v) => _contactName = v,
      ),
    ],
    const SizedBox(height: 28),
    GestureDetector(
      onTap: () => setState(() => _isRecording = !_isRecording),
      child: AnimatedContainer(
        duration: 300.ms,
        width: 72, height: 72,
        decoration: BoxDecoration(
          color: _isRecording ? NachiColors.red : NachiColors.neonBlue,
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: (_isRecording ? NachiColors.red : NachiColors.neonBlue).withOpacity(0.4), blurRadius: 24)],
        ),
        child: Center(child: Text(_isRecording ? '⏹' : '🎙️', style: const TextStyle(fontSize: 28))),
      ),
    ),
    const SizedBox(height: 12),
    Text(_isRecording ? 'Tap to stop' : 'Tap to start', style: const TextStyle(fontSize: 12, color: NachiColors.textMuted)),
  ]);
}
