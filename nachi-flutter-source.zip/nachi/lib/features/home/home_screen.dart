import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../shared/theme/app_theme.dart';
import '../recording/recording_sheet.dart';
import '../detail/detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  String _searchQuery = '';
  String _filterTag = 'All';
  final _searchController = TextEditingController();

  final _tags = ['All', 'Work', 'Family', 'Friend', 'Health', 'General'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NachiColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildSearch(),
            _buildTags(),
            Expanded(child: _buildContent()),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: _buildFab(),
    );
  }

  Widget _buildHeader() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('GOOD DAY', style: TextStyle(fontSize: 10, color: NachiColors.textMuted, letterSpacing: 2)),
          const SizedBox(height: 2),
          RichText(text: const TextSpan(
            style: TextStyle(fontFamily: 'Sora', fontSize: 24, fontWeight: FontWeight.w800, color: NachiColors.textPrimary),
            children: [TextSpan(text: 'Nachi '), TextSpan(text: '·', style: TextStyle(color: NachiColors.neonBlue))],
          )),
        ]),
        Row(children: [
          Container(width: 8, height: 8, decoration: const BoxDecoration(
            color: NachiColors.green, shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: NachiColors.green, blurRadius: 6)])),
          const SizedBox(width: 6),
          const Text('SECURE', style: TextStyle(fontSize: 10, color: NachiColors.green, letterSpacing: 1.5)),
        ]),
      ],
    ),
  );

  Widget _buildSearch() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: NachiColors.surface, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: NachiColors.border),
      ),
      child: Row(children: [
        const Text('🔍', style: TextStyle(fontSize: 16)),
        const SizedBox(width: 10),
        Expanded(child: TextField(
          controller: _searchController,
          style: const TextStyle(fontSize: 13, color: NachiColors.textSecondary, fontFamily: 'Sora'),
          decoration: const InputDecoration(
            border: InputBorder.none, hintText: 'Search "trip", "birthday", "movie"...',
            hintStyle: TextStyle(color: NachiColors.textMuted, fontSize: 13)),
          onChanged: (v) => setState(() => _searchQuery = v),
        )),
        if (_searchQuery.isNotEmpty)
          GestureDetector(onTap: () { _searchController.clear(); setState(() => _searchQuery = ''); },
            child: const Text('✕', style: TextStyle(color: NachiColors.textMuted, fontSize: 16))),
      ]),
    ),
  );

  Widget _buildTags() => SizedBox(
    height: 40,
    child: ListView.builder(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: _tags.length,
      itemBuilder: (_, i) {
        final tag = _tags[i];
        final selected = _filterTag == tag;
        return GestureDetector(
          onTap: () => setState(() => _filterTag = tag),
          child: AnimatedContainer(
            duration: 200.ms,
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: selected ? NachiColors.neonBlue.withOpacity(0.12) : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: selected ? NachiColors.neonBlue : NachiColors.border),
            ),
            child: Text(tag, style: TextStyle(
              fontSize: 12, fontFamily: 'Sora',
              color: selected ? NachiColors.neonBlue : NachiColors.textMuted)),
          ),
        );
      },
    ),
  );

  Widget _buildContent() => const Placeholder(color: NachiColors.border);

  Widget _buildBottomNav() => BottomAppBar(
    color: NachiColors.background, elevation: 0,
    shape: const CircularNotchedRectangle(), notchMargin: 8,
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
      _navBtn(0, '🏠', 'Home'),
      const SizedBox(width: 60),
      _navBtn(1, '⭐', 'Starred'),
    ]),
  );

  Widget _navBtn(int idx, String icon, String label) => GestureDetector(
    onTap: () => setState(() => _tab = idx),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Text(icon, style: TextStyle(fontSize: 22, color: _tab == idx ? Colors.white : Colors.white38)),
      Text(label, style: TextStyle(fontSize: 10, fontFamily: 'Sora',
        color: _tab == idx ? NachiColors.neonBlue : NachiColors.textMuted)),
    ]),
  );

  Widget _buildFab() => GestureDetector(
    onTap: () => showModalBottomSheet(
      context: context, isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const RecordingSheet()),
    child: Container(
      width: 60, height: 60,
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [NachiColors.neonBlue, NachiColors.purple]),
        shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: NachiColors.neonBlue.withOpacity(0.4), blurRadius: 20, spreadRadius: 2)],
      ),
      child: const Center(child: Text('🎙️', style: TextStyle(fontSize: 26))),
    ),
  );
}
