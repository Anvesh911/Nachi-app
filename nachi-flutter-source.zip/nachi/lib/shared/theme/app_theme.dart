import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class NachiColors {
  static const background = Color(0xFF070B14);
  static const surface = Color(0xFF0D1117);
  static const surfaceVariant = Color(0xFF0A0E1A);
  static const border = Color(0xFF1A2035);
  static const neonBlue = Color(0xFF00B4FF);
  static const purple = Color(0xFF7C5CFC);
  static const orange = Color(0xFFFF9F43);
  static const green = Color(0xFF55EFC4);
  static const red = Color(0xFFFF4757);
  static const pink = Color(0xFFFD79A8);
  static const textPrimary = Color(0xFFF0F4FF);
  static const textSecondary = Color(0xFFC8D6E5);
  static const textMuted = Color(0xFF4A5568);
  static const textDim = Color(0xFF8899AA);
}

ThemeData get nachiTheme => ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  scaffoldBackgroundColor: NachiColors.background,
  colorScheme: const ColorScheme.dark(
    primary: NachiColors.neonBlue,
    secondary: NachiColors.purple,
    surface: NachiColors.surface,
    background: NachiColors.background,
  ),
  textTheme: GoogleFonts.soraTextTheme(ThemeData.dark().textTheme),
  appBarTheme: const AppBarTheme(
    backgroundColor: NachiColors.background,
    elevation: 0,
    foregroundColor: NachiColors.textPrimary,
  ),
  cardTheme: CardTheme(
    color: NachiColors.surface,
    elevation: 0,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(16),
      side: const BorderSide(color: NachiColors.border),
    ),
  ),
);
